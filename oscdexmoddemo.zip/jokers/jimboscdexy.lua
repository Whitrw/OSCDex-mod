SMODS.Joker{ --JIMBOSCDexy
    key = "jimboscdexy",
    config = {
        extra = {
            dollars = 1
        }
    },
    loc_txt = {
        ['name'] = 'JIMBOSCDexy',
        ['text'] = {
            [1] = 'Gives {C:money}1${} when another joker',
            [2] = 'is triggered'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["oscdex_mycustom_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.other_joker  then
            return {
                dollars = card.ability.extra.dollars
            }
        end
    end
}