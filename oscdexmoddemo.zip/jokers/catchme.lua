SMODS.Joker{ --Catch me
    key = "catchme",
    config = {
        extra = {
            n = 0
        }
    },
    loc_txt = {
        ['name'] = 'Catch me',
        ['text'] = {
            [1] = 'If the first hand is',
            [2] = '{C:attention}a flush{} get a {C:tarot}tarot{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["oscdex_oscdex_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.after and context.cardarea == G.jokers  then
            if (G.GAME.current_round.hands_played == 0 and context.scoring_name == "Flush") then
                return {
                    func = function()
                        for i = 1, 1 do
                            G.E_MANAGER:add_event(Event({
                                trigger = 'after',
                                delay = 0.4,
                                func = function()
                                    play_sound('timpani')
                                    SMODS.add_card({ set = 'Tarot', soulable = true, })                            
                                    card:juice_up(0.3, 0.5)
                                    return true
                                end
                            }))
                        end
                        delay(0.6)
                        if created_consumable then
                            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                        end
                        return true
                    end
                }
            end
        end
    end
}