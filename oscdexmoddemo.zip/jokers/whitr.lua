SMODS.Joker{ --Whitr
    key = "whitr",
    config = {
        extra = {
            Xmult = 3,
            chips = 52
        }
    },
    loc_txt = {
        ['name'] = 'Whitr',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult and {C:blue}+52{} Chips if',
            [2] = 'hand contains a 5 and a 2',
            [3] = '{C:inactive}(52 mentioned!!!!){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["oscdex_oscdexmo_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
                local rankCount = 0
                for i, c in ipairs(context.full_hand) do
                    if c:get_id() == 5 then
                        rankCount = rankCount + 1
                    end
                end
                return rankCount >= 1
            end)() and (function()
                local rankCount = 0
                for i, c in ipairs(context.scoring_hand) do
                    if c:get_id() == 2 then
                        rankCount = rankCount + 1
                    end
                end
                return rankCount >= 1
            end)()) then
                return {
                    Xmult = card.ability.extra.Xmult,
                    extra = {
                        chips = card.ability.extra.chips,
                        colour = G.C.CHIPS
                    }
                }
            end
        end
    end
}