SMODS.Joker{ --No ways has died this round
    key = "nowayshasdiedthisround",
    config = {
        extra = {
            dollars = 10
        }
    },
    loc_txt = {
        ['name'] = 'No ways has died this round',
        ['text'] = {
            [1] = 'Each time {C:attention}cards get destroyed{}',
            [2] = 'this gives {C:money}10${}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = false,
    eternal_compat = false,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["oscdex_oscdexmo_jokers"] = true },

    set_ability = function(self, card, initial)
        card:add_sticker('perishable', true)
    end,

    
    calculate = function(self, card, context)
        if context.remove_playing_cards  and not context.blueprint then
            return {
                dollars = card.ability.extra.dollars
            }
        end
    end
}