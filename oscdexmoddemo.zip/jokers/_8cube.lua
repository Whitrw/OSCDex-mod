SMODS.Joker{ --8-Cube
    key = "_8cube",
    config = {
        extra = {
            chips = 8,
            mult = 8
        }
    },
    loc_txt = {
        ['name'] = '8-Cube',
        ['text'] = {
            [1] = '{C:blue}+8{} Chips and {C:red}+8{} Mult for',
            [2] = 'every {C:attention}8{} scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = false,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["oscdex_oscdexmo_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 8 then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        mult = card.ability.extra.mult
                    }
                }
            end
        end
    end
}