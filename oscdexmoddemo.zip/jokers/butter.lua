SMODS.Joker{ --Butter
    key = "butter",
    config = {
        extra = {
            chips = 15,
            Xmult = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Butter',
        ['text'] = {
            [1] = '{C:blue}+15{} Chips and {X:red,C:white}X1.5{} Mult',
            [2] = 'if hand contains both',
            [3] = 'a scoring ace and',
            [4] = 'a scoring 5'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["oscdex_oscdexmo_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if ((function()
                local rankCount = 0
                for i, c in ipairs(context.scoring_hand) do
                    if c:get_id() == 5 then
                        rankCount = rankCount + 1
                    end
                end
                return rankCount >= 1
            end)() and (function()
                local rankCount = 0
                for i, c in ipairs(context.scoring_hand) do
                    if c:get_id() == 14 then
                        rankCount = rankCount + 1
                    end
                end
                return rankCount >= 1
            end)()) then
                return {
                    chips = card.ability.extra.chips,
                    extra = {
                        Xmult = card.ability.extra.Xmult
                    }
                }
            end
        end
    end
}