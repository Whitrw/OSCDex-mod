SMODS.Joker{ --Melodyy
    key = "melodyy",
    config = {
        extra = {
            Xmult = 2.5
        }
    },
    loc_txt = {
        ['name'] = 'Melodyy',
        ['text'] = {
            [1] = '{X:red,C:white}X2.5{} Mult if hand contains',
            [2] = 'flush or full house'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["oscdex_oscdexmo_jokers"] = true },

    
    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (next(context.poker_hands["Flush"]) or next(context.poker_hands["Full House"])) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}